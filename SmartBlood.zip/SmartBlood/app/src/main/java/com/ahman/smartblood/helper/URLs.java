package com.ahman.smartblood.helper;

public class URLs {
    private static final String ROOT_URL = "http://10.0.0.2/SmartBlood/android/api.php?apicall=";
    public static final String URL_ALL =  "http://10.0.0.2/SmartBlood/android/";
    public static final String URL_REGISTER = ROOT_URL + "signup";
    public static final String URL_LOGIN = ROOT_URL + "login";
}