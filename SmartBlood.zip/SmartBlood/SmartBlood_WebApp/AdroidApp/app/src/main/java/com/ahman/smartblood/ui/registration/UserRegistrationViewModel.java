package com.ahman.smartblood.ui.registration;

import android.arch.lifecycle.ViewModel;

public class UserRegistrationViewModel extends ViewModel {
    // TODO: Implement the ViewModel

}
